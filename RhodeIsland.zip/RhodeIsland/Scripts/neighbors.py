from qgis.utils import iface
from PyQt4.QtCore import QVariant
import numpy
import csv

LAYER_NAME = "Block_Group"
FILEPATH='c:\\Users\\assaf\\Desktop\\Holding_Bay'

_NAME_FIELD = 'GEOID'
_NEW_NEIGHBORS_FIELD = 'NEIGHBORS'
ADJ_LAYER_NAME = LAYER_NAME+"_Adj"

# Replace the values below with values from your layer.
# For example, if your identifier field is called 'XYZ', then change the line
# below to _NAME_FIELD = 'XYZ'
layers = qgis.utils.iface.legendInterface().layers()
for layerQ in layers:
    if layerQ.name() == LAYER_NAME:
        layer=layerQ

layer.startEditing()
if not "NEIGHBORS" in [field.name() for field in layer.pendingFields()]:
    layer.dataProvider().addAttributes([QgsField(_NEW_NEIGHBORS_FIELD, QVariant.String),])
    layer.updateFields()
# Create a dictionary of all features
feature_dict = {f.id(): f for f in layer.getFeatures()}

# Build a spatial index
index = QgsSpatialIndex()
for f in feature_dict.values():
    index.insertFeature(f)

Feature_List=[]
Feature_NBS=[]

# create a new memory layer
v_layer = QgsVectorLayer("LineString", ADJ_LAYER_NAME, "memory")
pr = v_layer.dataProvider()
for f in feature_dict.values():
    print 'Working on %s' % f[_NAME_FIELD]
    Feature_List.append(int(f[_NAME_FIELD]))
    geom = f.geometry()
    start_pt = geom.centroid().asPoint()
    # Find all features that intersect the bounding box of the current feature.
    # We use spatial index to find the features intersecting the bounding box
    # of the current feature. This will narrow down the features that we need
    # to check neighboring features.
    intersecting_ids = index.intersects(geom.boundingBox())
    # Initalize neighbors list and sum
    neighbors = []
    for intersecting_id in intersecting_ids:
        # Look up the feature from the dictionary
        intersecting_f = feature_dict[intersecting_id]

        # For our purpose we consider a feature as 'neighbor' if it touches or
        # intersects a feature. We use the 'disjoint' predicate to satisfy
        # these conditions. So if a feature is not disjoint, it is a neighbor.
        if (f != intersecting_f and
            not intersecting_f.geometry().disjoint(geom)):
            neighbors.append(int(intersecting_f[_NAME_FIELD]))
            
            end_pt=intersecting_f.geometry().centroid().asPoint()
            line=QgsGeometry.fromPolyline([start_pt,end_pt])
            # create a new feature
            seg = QgsFeature()
            # add the geometry to the feature, 
            seg.setGeometry(QgsGeometry.fromPolyline([start_pt, end_pt]))
            # ...it was here that you can add attributes, after having defined....
            # add the geometry to the layer
            pr.addFeatures( [ seg ] )
            # update extent of the layer (not necessary)
            v_layer.updateExtents()
    f[_NEW_NEIGHBORS_FIELD] = ''.join(str(x) for x in neighbors)
    Feature_NBS.append(neighbors)
    # Update the layer with new attribute values.
    layer.updateFeature(f)

layer.commitChanges()
print 'Processing complete.'
QgsMapLayerRegistry.instance().addMapLayers([v_layer])
numpy.savetxt(FILEPATH+'\\BlockGroupList.txt',Feature_List , fmt='%d')
with open(FILEPATH+"\\BlockGroupNBS.txt", "wb") as f:
    writer = csv.writer(f)
    writer.writerows(Feature_NBS)